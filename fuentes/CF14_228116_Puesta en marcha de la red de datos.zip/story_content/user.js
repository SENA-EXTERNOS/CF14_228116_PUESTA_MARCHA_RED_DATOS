function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6Ygw6LXMUv5":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

